function updateIframeSrc(iframe) {
  const src = iframe.src;
  if (src.includes('tgWebAppPlatform=weba') || src.includes('tgWebAppPlatform=web')) {
    const newSrc = src.replace(/tgWebAppPlatform=(weba|web)/, 'tgWebAppPlatform=ios');
    iframe.src = newSrc;
    console.log('Iframe src updated:', newSrc);
  } else {
    console.log('Iframe already has ios platform or different parameter:', src);
  }
}

function waitForIframe() {
  return new Promise((resolve) => {
    const checkIframe = () => {
      const iframes = document.querySelectorAll('iframe');
      if (iframes.length > 0) {
        iframes.forEach((iframe) => {
          const src = iframe.src;
          if (src && (src.includes('tgWebAppPlatform=weba') || src.includes('tgWebAppPlatform=web'))) {
            console.log('Iframe found with matching src:', iframe);
            resolve(iframe);
          }
        });
      } else {
        requestAnimationFrame(checkIframe);
      }
    };
    checkIframe();
  });
}

if (window.location.hostname === 'web.telegram.org' && window.location.protocol === 'https:') {
  console.log('On the correct domain, starting iframe observer...');
  
  waitForIframe().then((iframe) => {
    updateIframeSrc(iframe);
  }).catch((error) => {
    console.error('Error waiting for iframe:', error);
  });
} else {
  console.log('Not on the correct domain, script will not run.');
}
